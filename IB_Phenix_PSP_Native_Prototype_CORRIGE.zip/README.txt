IB PHÉNIX — Prototype PSP natif
================================

Cette version remplace le prototype Lua par un petit programme PSP natif en C,
basé sur PSPSDK. Elle est conçue pour produire EBOOT.PBP, le format homebrew
que PPSSPP peut lancer.

Arborescence:
  main.c
  CMakeLists.txt

Compilation avec PSPSDK:
  mkdir build
  cd build
  psp-cmake ..
  make

Le résultat attendu est:
  build/EBOOT.PBP

Pour PPSSPP:
  créer le dossier:
  PSP/GAME/IBPHENIX/

  puis y placer:
  EBOOT.PBP

Commandes:
  D-pad = déplacer P
  X = attaquer E quand on est proche
  START = retour au menu
  X sur victoire/défaite = recommencer

Ce prototype est volontairement simple : son objectif est de vérifier la chaîne
PSP -> EBOOT.PBP -> PPSSPP avant d'ajouter graphismes, sons, maps et combats avancés.
