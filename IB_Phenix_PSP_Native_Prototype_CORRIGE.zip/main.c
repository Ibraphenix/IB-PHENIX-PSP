
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <stdio.h>
#include <string.h>

PSP_MODULE_INFO("IBPHENIX", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);

static int running = 1;

static int exit_callback(int arg1, int arg2, void *common) {
    running = 0;
    return 0;
}

static int callback_thread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

static int setup_callbacks(void) {
    int thid = sceKernelCreateThread("update_thread", callback_thread,
                                     0x11, 0xFA0, 0, 0);
    if (thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

int main(void) {
    setup_callbacks();
    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    int menu = 1;
    int px = 10, py = 8;
    int enemy_hp = 3;
    int player_hp = 5;
    int win = 0, lose = 0;

    while (running) {
        SceCtrlData pad;
        sceCtrlReadBufferPositive(&pad, 1);

        if (menu) {
            pspDebugScreenClear();
            pspDebugScreenSetXY(10, 4);
            pspDebugScreenPrintf("=== IB PHENIX - PSP PROTOTYPE ===\n\n");
            pspDebugScreenPrintf("          X  COMMENCER L'AVENTURE\n\n");
            pspDebugScreenPrintf("      Prototype natif PSP / PPSSPP\n\n");
            pspDebugScreenPrintf("      Croix = commencer\n");
            pspDebugScreenPrintf("      START = quitter\n");

            if (pad.Buttons & PSP_CTRL_CROSS) menu = 0;
            if (pad.Buttons & PSP_CTRL_START) running = 0;
        } else if (win || lose) {
            pspDebugScreenClear();
            pspDebugScreenSetXY(12, 6);

            if (win)
                pspDebugScreenPrintf("VICTOIRE !\n\n");
            else
                pspDebugScreenPrintf("DEFAITE...\n\n");

            pspDebugScreenPrintf("X = recommencer\n");
            pspDebugScreenPrintf("START = menu\n");

            if (pad.Buttons & PSP_CTRL_CROSS) {
                px = 10; py = 8; enemy_hp = 3; player_hp = 5;
                win = lose = 0;
            }
            if (pad.Buttons & PSP_CTRL_START) menu = 1;
        } else {
            if (pad.Buttons & PSP_CTRL_LEFT)  px--;
            if (pad.Buttons & PSP_CTRL_RIGHT) px++;
            if (pad.Buttons & PSP_CTRL_UP)    py--;
            if (pad.Buttons & PSP_CTRL_DOWN)  py++;

            if (px < 1) px = 1;
            if (px > 45) px = 45;
            if (py < 5) py = 5;
            if (py > 18) py = 18;

            /* Enemy is at (35, 12). Cross attacks if close. */
            int dx = px - 35;
            int dy = py - 12;
            if ((pad.Buttons & PSP_CTRL_CROSS) &&
                dx >= -3 && dx <= 3 && dy >= -2 && dy <= 2) {
                enemy_hp--;
                if (enemy_hp <= 0) win = 1;
            }

            if (px == 35 && py == 12 && enemy_hp > 0) {
                player_hp--;
                if (player_hp <= 0) lose = 1;
            }

            if (pad.Buttons & PSP_CTRL_START) menu = 1;

            pspDebugScreenClear();
            pspDebugScreenSetXY(2, 1);
            pspDebugScreenPrintf("IB PHENIX    PV: %d/5    ENNEMI: %d/3\n\n",
                                  player_hp, enemy_hp);
            pspDebugScreenPrintf("D-PAD: bouger   X: attaquer   START: menu\n\n");

            for (int y = 5; y <= 18; y++) {
                pspDebugScreenSetXY(2, y);
                for (int x = 1; x <= 45; x++) {
                    if (x == px && y == py)
                        pspDebugScreenPrintf("P");
                    else if (x == 35 && y == 12 && enemy_hp > 0)
                        pspDebugScreenPrintf("E");
                    else
                        pspDebugScreenPrintf(".");
                }
            }
        }

        sceDisplayWaitVblankStart();
    }

    sceKernelExitGame();
    return 0;
}
